// Joshua Ginn, A5, CIS425, 1:30pm

"use strict";

var student = new Object()


function register(){

    const firstName = document.getElementById("fnamex").value;
    const lastName = document.getElementById("lnamex").value;
    const semester = document.getElementById("semesterx").value;
    const course = document.getElementById("coursex").value;


    student.fname = firstName;
    student.lname = lastName;
    student.semester = semester;
    student.course = course;


    displayResults();
}

function displayResults(){

    const results = document.getElementById("displayResults");

    results.innerHTML = `Student Registered:<br><strong> ${student.fname} ${student.lname}</strong><br>For Class: <strong>${student.course}</strong><br>During the: <strong>${student.semester}</strong> Semester`;


    document.getElementById("fnamex").innerText = "";
    document.getElementById("lnamex").innerText = "";
    document.getElementById("semesterx").innerHTML = "";
    document.getElementById("coursex").innerHTML = "";

    
}