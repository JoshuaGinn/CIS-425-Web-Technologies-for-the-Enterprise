// Joshua Ginn , P2, CIS425, 1:30pm

let movie;

let http = require('http');
let mysql  = require("mysql");
let events = require('events');

// Will store HTML resonse output
let sqlquery;
let output = '';
let res;

let eventEmitter = new events.EventEmitter();

eventEmitter.on("processingFinished", processingFinishedHandler);



let httpServer = http.createServer( processRequest );

const PORT = 8080;
httpServer.listen( PORT );

function processRequest(request, response){

    console.log(request.url)
    res = response;

    // get the base for the URL
    let base = "http://" + request.headers["host"];

    response.writeHead( 200, {'Content-Type':'text/html'} );

    response.write("<head>  <link rel='icon' href='data:;base64,iVBORw0KGgo='></head>");

    // let's construct a URL object
    let url = new URL(request.url, base);
    console.log(`full URL is ${url.href}`);

    // get the search string
    let searchString = url.search;
    console.log(`search string is ${searchString}`);
 
    movie = url.searchParams.get("movie");

    if (movie == 1){
        sqlquery = "select title, description from film where title = 'Balloon Homeward';";
    }
    else if (movie == 2){
        sqlquery = "select title, description from film where title = 'Homicide Peach';";  
    }
    else if (movie == 3){
        sqlquery = "select title, description from film where title = 'Moonshine Cabin';";   
    }
    else if (movie == 4){
        sqlquery = "select title, description from film where title = 'Run Pacific';";  
    }
    

    initializeDB();

}


// method to connect to database and perform other database tasks
function initializeDB (){

    // Declares variable to assign as javascript object (using JSON name structure)
    let connectionString = {

        host: "cis425.wpcclasses.com",
        database: "sakila",
        user: "cis425Fall2021User" ,
        password: "cis425Fall2021"
    };

    // logged host value to console
    console.log(`${connectionString.host}`);

    // Creates a mysql connection object
    let con = mysql.createConnection(connectionString);

    console.log(`I am going to connect to the database.`);
    
    
    // Starts the connection by invoking connect method of the con object
    con.connect(

        function (err){

            if (err){
                console.log(`The was an error.`);
                throw err;
            }
            else{
                console.log("Connected to the database");

                // let sqlQuery = "select first_name, last_name from actor;";
                con.query( sqlquery, processResult);

                // Terminates connection
                con.end();
            }
        }


    );


}// End InitializeDB

// Method that processes the results of query
function processResult(err, result){

    if(err){
        console.log(`There has been an error.`);
        throw err;
    } 
    else{
        // print how many rows were returned
        console.log(`you made it here traveler`);
        result.forEach( printMovie );
        console.log(`${output}`)
        eventEmitter.emit("processingFinished");
    }
}

function printMovie( record ){
    // this method is going to process ONE record
    console.log(`made it to print movie log`);
    // print out the record information to the console (Or HTML page)
    output += `<p>${record.title}: <strong>${record.description}</strong></p>`;

}

function processingFinishedHandler(){
    res.write(`The Movie you selected was:`)
    res.write(`${output}`);
    res.end();
}
