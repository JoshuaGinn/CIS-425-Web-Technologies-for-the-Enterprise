// Joshua Ginn, E11, CIS425, 1:30pm

let http = require('http');

let httpServer = http.createServer( processRequest )

const PORT = 8080;
httpServer.listen( PORT );

function processRequest(request, response){


    console.log(request.url)


    // get the base for the URL
    let base = "http://" + request.headers["host"];

    response.writeHead( 200, {'Content-Type':'text/html'} );

    response.write("<head>  <link rel='icon' href='data:;base64,iVBORw0KGgo='></head>");

    // let's construct a URL object
    let url = new URL(request.url, base);
    console.log(`full URL is ${url.href}`);

    // get the search string
    let searchString = url.search;
    console.log(`search string is ${searchString}`);

    let name = url.searchParams.get("name");
    let id = url.searchParams.get("id");


    if (name !== ""){
        response.write(`<p>Here is the information you sent to the server.</p>`);
        
        response.write(createResponseText(name, id));
        response.end();
    }
}

function createResponseText(name, id){
    let text = `<p><em>Name:</em> <strong>${name}</strong></p>` + `<p><em>ID:</em> <strong>${id}</strong></p>`;
    return text;
}