//  Joshua Ginn, Project 1, CIS425, 1:30pm

var firstNumber = '';
var secondNumber = null;
var operator = null;
var answer;


function handleButton(number){

    const displayRef  = document.getElementById("display");
    const displayLabelRef = document.getElementById("displayLabel");


    if (operator == null){
        if (firstNumber === '' &&  (number == "0" || number == ".")) {
            console.log(`Leading zero/decimal not printed- but Zero is still divide-able`)

        }
        else {
            if (firstNumber.includes('.') && number == '.'){
                console.log(`Second decimal ignored`)   
            }
            else {
                firstNumber += number;
                displayRef.value += number;
                displayLabelRef.textContent = `${firstNumber}`;
            }
        }
    }
    else {
        if (secondNumber === null){
            displayRef.value = '';
            secondNumber = '';
        }   
            
        if (secondNumber === '' &&  (number == "0" || number == ".")) {
            console.log(`Initial zero/decimal not posted`);

        }
        else {
            if (secondNumber.includes('.') && number == '.'){
                console.log(`Second decimal ignored`);  
            }
            else {
                secondNumber += number;
                displayRef.value += number;
                displayLabelRef.textContent = `${firstNumber} ${operator} ${secondNumber}`;
            }
        }
    }
}


function handleOperator(theOperator){
    
    const displayRef  = document.getElementById("display");
    const displayLabelRef = document.getElementById("displayLabel");
    
    if (secondNumber == null)

        switch(theOperator) {
            case "/":
                operator = '/';
                displayLabelRef.textContent = `${firstNumber} ${operator}`;
                displayRef.value = '/';
                break;
            case "-":
                operator = '-';
                displayLabelRef.textContent = `${firstNumber} ${operator}`;
                displayRef.value = '-';
                break;
            case "*":
                operator = '*';
                displayLabelRef.textContent = `${firstNumber} ${operator}`;
                displayRef.value = '*';
                break;
            case "+":
                operator = '+';
                displayLabelRef.textContent = `${firstNumber} ${operator}`;
                displayRef.value = '+';
                break;
            default:
                break;
        }
    else {

        if (firstNumber === ''){
            firstNumber = "0";
        }

        switch(operator) {
            case "/":
                answer = parseFloat(firstNumber) / parseFloat(secondNumber);
                break;
            case "-":
                answer = parseFloat(firstNumber) - parseFloat(secondNumber);
                break;
            case "*":
                answer = parseFloat(firstNumber) * parseFloat(secondNumber);
                break;
            case "+":
                answer = parseFloat(firstNumber) + parseFloat(secondNumber);
                break;
        }
        
    displayLabelRef.textContent = `${firstNumber} ${operator} ${secondNumber} = ${answer}`;
    displayRef.value = `${answer}`;
    firstNumber = answer;    
    secondNumber = null;
    operator = null;
    }

}


function clearAll(){

    firstNumber = '';    
    secondNumber = null;
    operator = null;

    const displayRef  = document.getElementById("display");
    const displayLabelRef = document.getElementById("displayLabel");

    displayLabelRef.textContent = '';
    displayRef.value = '';
}
