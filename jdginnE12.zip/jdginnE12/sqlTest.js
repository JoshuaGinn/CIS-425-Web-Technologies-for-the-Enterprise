// Joshua Ginn, E12, CIS425, 1:30pm


// import the http module/library
let http = require("http");
let mysql  = require("mysql");

// Will store HTML resonse output
let output = '';

initializeDB();

// Creating Node.js Server
// defining httpserver as 
let httpServer = http.createServer( processServerRequest )

const PORT = 8080;

httpServer.listen( PORT );

// start server listening, connecting server to listen on port 8080



// method to connect to database and perform other database tasks
function initializeDB (){

    // Declares variable to assign as javascript object (using JSON name structure)
    let connectionString = {

        host: "cis425.wpcclasses.com",
        database: "sakila",
        user: "cis425Fall2021User" ,
        password: "cis425Fall2021"
    };

    // logged host value to console
    console.log(`${connectionString.host}`);

    // Creates a mysql connection object
    let con = mysql.createConnection(connectionString);

    console.log(`I am going to connect to the database.`);
    
    
    // Starts the connection by invoking connect method of the con object
    con.connect(

        function (err){

            if (err){
                console.log(`The was an error.`);
                throw err;
            }
            else{
                console.log("connected to the database");
                let sqlQuery = "select first_name, last_name from actor;";
                con.query( sqlQuery, processResult);

                // Terminates connection
                con.end();
            }
        }


    );


}// End InitializeDB

// Method that processes the HTTP requests
function processServerRequest( request, response ){
    //logs request of URL to the console
    console.log(request.url);

    // creates response
    response.writeHead( 200, {'Content-Type':'text/html'} );

    // creates response of 'output' variable
    response.write(`${output}`);

    response.end();

}

// Method that processes the results of query
function processResult(err, result){

    if(err){
        console.log(`There has been an error.`)
        throw err;
    } 
    else{
        // print how many rows were returned
        console.log(`There were ${result.length} rows returned`);
        result.forEach( printActor );
    }
}

function printActor( record ){
    // this method is going to process ONE record

    // print out the record information to the console (Or HTML page)
    output += `<p>${record.first_name} <strong>${record.last_name}</strong></p>`;

}
