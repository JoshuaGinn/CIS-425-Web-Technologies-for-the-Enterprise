// Joshua Ginn, A4, CIS425, 1:30pm

"use strict";
function average() {
    let average = 0;
    for (let i=1; i<=10; i++) {
        average = average + i;
    }
    average = average/10;
    console.log('Average is ' + average);
}

function isEven(number) {
    
    let evenNumber = true;
    if (number%2 ===0) {
        evenNumber = true;
    }
    else {
        evenNumber = false;
    }
    
    return evenNumber;
}

function testNumber(number){
    let even = isEven(number);
    if (even === true) {
        console.log(number + " is even.");
    }
    else {
        console.log(number + " is odd.");
    }
}

function dayActivity(day){
    let output;
    switch(day) {
    case "Monday":
        output = ('Not again!');
        break;
    case "Wednesday":
        output = ('Half way there!');
        break;
    case "Friday":
        output = ('TGIF!');
        break;
    case "Sunday":
        output = ('Sunday Funday!');
        break;
    default:
        output = ('Just another day!');
        break;
    }

    console.log(day + ": " + output);
}

function printTable(){
    for (let i =1; i<=5; i++){

        for (let j= 1;j <=4;j++){
            console.log(i +" * " + j + " = " + (i*j));
            
        }
        console.log('');
    }
}