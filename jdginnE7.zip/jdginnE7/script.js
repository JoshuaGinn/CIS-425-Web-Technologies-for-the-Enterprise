// Joshua Ginn, E7, CIS425, 1:30pm

document.write("Factorials<br><br>");
            
    var factorial = 1;

    for (var i = 1; i < 11; i++) {
        factorial = factorial * i;
                
        console.log( `${i} factorial is ${factorial}.\n\n`);
        document.write(`\t${i} factorial is ${factorial}.<br><br>`)
    
    }