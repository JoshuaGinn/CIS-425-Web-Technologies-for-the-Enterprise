// Joshua Ginn, A7, 1:30, CIS425

let http = require('http');

let httpServer = http.createServer( processRequest )

const PORT = 8080;
httpServer.listen( PORT );

function processRequest(request, response){


    console.log(request.url)


    // get the base for the URL
    let base = "http://" + request.headers["host"];

    response.writeHead( 200, {'Content-Type':'text/html'} );

    response.write("<head>  <link rel='icon' href='data:;base64,iVBORw0KGgo='></head>");

    // let's construct a URL object
    let url = new URL(request.url, base);
    console.log(`full URL is ${url.href}`);

    // get the search string
    let searchString = url.search;
    console.log(`search string is ${searchString}`);

    let name = url.searchParams.get("name");
    let positions = url.searchParams.get("positions");
    let major = url.searchParams.get("major");
    let email = url.searchParams.get("email");
    let semesters = url.searchParams.get("semesters");
    let solicitaionRequest = url.searchParams.get("solicitationRequest")


    if (name !== ""){
        response.write(`<p>Here is the information you sent to the server.</p>`);
        
        response.write(createResponseText(name, positions, major, email, semesters, solicitaionRequest));
        response.end();
    }
}

function createResponseText(name, positions, major, email, semesters, solicitaionRequest){
    let text = `<p>Your name is <strong>${name}.</strong></p>` + `<p>The types of positions you are looking for are <strong>${positions}</strong>.</p>`;
    text += `<p>Your major is <strong>${major}</strong>.</p>` + `<p>Your E-mail adress is <strong>${email}</strong></p>` + `<p>You have <strong>${semesters}</strong> semesters left until you graduate.</p>` 
    text += `<p>You <strong>${solicitaionRequest}</strong> want to receive more information by e-mail.</p>`;
    return text;
}