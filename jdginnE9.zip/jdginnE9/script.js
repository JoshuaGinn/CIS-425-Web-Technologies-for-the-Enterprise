// Joshua Ginn E9, CIS425, 1:30pm

"use strict";

function process(){

    const formElements = document.getElementsByClassName("forms");

    let dataText = "<p>";
    
    dataText += "Data entered is:<br>"
    for(let i=0; i < formElements.length; i++){

        dataText += formElements[i].value + "<br>";
        
    }

    dataText += "</p>";
    
    // Test Datatext
    // console.log(`form data is ${dataText}`);

    let emailAddress = `${formElements[0].value}.${formElements[1].value}@asu.edu`;
    

    // console.log(`${emailAddress}`);

    let emailText = `<p>Generated E-mail: ${emailAddress}</p>`;

    let password = "";
    
    for(let i=0; i<10; i++) {

        password += Math.round(Math.random()*10);

    }
    
    let passwordText = `<p>Temporary password is: <span id="pwd">${password}</span></p>`;


    const result = document.getElementById("result");

    result.innerHTML = `${dataText} ${emailText} ${passwordText}`;

    const passwordElement = document.getElementById("pwd");

    passwordElement.setAttribute("style", "font-weight: bold;");
}