// Joshua Ginn, E13, CIS425, 1:30pm

let http = require('http');
let mysql = require('mysql');
let events = require('events');

let sqlquery;
let output;
let res;

let eventEmitter = new events.EventEmitter();

eventEmitter.on("processingFinshed", processingFinishedHandler);

let httpServer = http.createServer( processServerRequest );

const PORT = 8080;
httpServer.listen( PORT );

function processServerRequest(request, response){
    console.log(request.url);
    res = response;

    response.writeHead( 200, {'Content-Type':'text/html'} );

    response.write("<head>  <link rel='icon' href='data:;base64,iVBORw0KGgo='></head>");

    sqlquery = "select first_name, last_name from actor limit 5;";

    initializeDB();
}

function initializeDB(){

    let connectionString = {

        host: "cis425.wpcclasses.com",
        database: "sakila",
        user: "cis425Fall2021User" ,
        password: "cis425Fall2021"
    };

    console.log(`${connectionString.host}`);

    let con = mysql.createConnection(connectionString);

    console.log(`I am going to connect to the database.`);

    con.connect(

        function (err){

            if (err){
                console.log(`The was an error.`);
                throw err;
            }
            else{
                con.query( sqlquery, processResult);
                con.end();
            }
        }
    );
}

function processResult(err, result){

    if(err){
        console.log(`There has been an error.`);
        throw err;
    }
    else{
        result.forEach( printRecord);
        eventEmitter.emit("processingFinished");

    }
}

function printRecord(record){
    output += `<p>${record.first_name} ${record.last_name}</p>`;

}

function processingFinishedHandler(){

    response.write(`${output}`);
    res.end();
}
