// Joshua Ginn, E8, CIS425, 1:30pm


"use strict";

const scores = [];
const names = ['Mary', 'John', 'Peter', 'Susan'];
initialize(78, 85, 89, 94);

function initialize(n1, n2, n3, n4) {
    console.log('initializing...');
    scores.push(n1,n2,n3,n4);

}

function printOneElement(element) {
    console.log(element);
}

function printScores() {
    console.log('Students in the array are: ')
    for (let i=0; i < names.length; i++) {
        console.log(names[i]);
    }

    console.log('Corresponding scores in the parallel array are: ')
    scores.forEach( printOneElement )

}

function calculateAverage() {
    let total = 0;
    let average = 0;

    for (let i=0; i < scores.length; i++) {
        total = total + scores[i];
    }
    average = total / (names.length)
    return average;
}

function printAverage() {
    console.log('Average of all scores is ' + calculateAverage());
    console.log('');

}

function addElements (newNames, newScores) {
    for (let i=0; i < newScores.length; i++) {
        names.unshift(newNames[i]);
        scores.unshift(newScores[i]);
    }
     console.log('Updated Database')
    for (let i=0; i < scores.length; i++) {
        console.log( names[i] + ' : ' + scores[i]);
    }  
}