// Joshua Ginn E10, CIS425, 1:30pm

// array of scores
var scores = [];

var runningTotalAllScores;


function addScore(){

    // event handler 
    let name = document.getElementById("name").value;
    let score1 = document.getElementById("score1").value;
    let score2 = document.getElementById("score2").value;
    let score3 = document.getElementById("score3").value;
      
    score1 = parseFloat(score1);
    score2 = parseFloat(score2);
    score3 = parseFloat(score3);

    let newScore = { name: name, num1: score1, num2: score2, num3: score3};
    
    console.log(`${newScore.name}, ${newScore.num1}, ${newScore.num2}`);
    scores.push(newScore);
    addTableRow(newScore);
}

// add more functions below

function addTableRow(scoreObject){

    const existingTable = document.getElementById("outputTable");

    let newRow = document.createElement("tr");

    let newCol1 = document.createElement("td");
    newCol1.textContent = scoreObject.name;

    let newCol2 = document.createElement("td");
    newCol2.textContent = scoreObject.num1;

    let newCol3 = document.createElement("td");
    newCol3.textContent = scoreObject.num2;

    let newCol4 = document.createElement("td");
    newCol4.textContent = scoreObject.num3;

    newRow.appendChild(newCol1);
    newRow.appendChild(newCol2);
    newRow.appendChild(newCol3);
    newRow.appendChild(newCol4);

    existingTable.appendChild(newRow);

    existingTable.style.visibility = "visible";
    let average = updateAverage();
    let averageParagraph = document.getElementById("averageParagraph");

    averageParagraph.innerHTML = `Overall Average is ${average}`;

}

function updateAverage() {
    let runningTotalAllScores = parseFloat(0);
    var total = 0;
    var numberOfScores = 0;
    let averageOfScores = 0;

    for(let i=0; i < scores.length; i++){

        total =+ scores[i].num1 + scores[i].num2 + scores[i].num3;
        
        runningTotalAllScores += parseFloat(total);
        
    }
    
    numberOfScores = scores.length*3;

    averageOfScores = runningTotalAllScores/numberOfScores

    return Number.parseFloat(averageOfScores);

}